# Better ~~Call Saul~~ Console
*Breaking ~~Bad~~ the Console*<br>

<details>
    <summary>Jumpscare</summary>
    <img alt="Better Callsole" src="https://github.com/gingerphoenix10/BetterConsole/blob/main/BetterConsaul.png?raw=true" />
</details>

A mod to improve the Debug console built into the game a little bit.
### Currently:
- Adds Paste bind
- Adds Copy bind (that copies the entire line since no selection)

### Planned (hopefully):
- Selection of input text